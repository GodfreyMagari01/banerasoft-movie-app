import { useEffect, useState } from 'react'
import {
  Box,
  Container,
  Grid,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Slider,
  Button,
  Typography,
  Pagination,
  Stack,
  CircularProgress
} from '@mui/material'
import MovieCard from '../components/MovieCard'
import { getGenres, searchMovies, discoverMovies } from '../services/tmdb'

/*
 * Movies page provides a searchable, filterable catalogue of films. Users
 * can search by title or keyword, filter by genre, release year and
 * minimum rating, and sort by various criteria. Results are paginated.
 */

export default function Movies () {
  const [genres, setGenres] = useState([])
  const [query, setQuery] = useState('')
  const [selectedGenre, setSelectedGenre] = useState('')
  const [year, setYear] = useState('')
  const [rating, setRating] = useState(0)
  const [sort, setSort] = useState('popularity.desc')
  const [movies, setMovies] = useState([])
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  // Load available genres on first render
  useEffect(() => {
    async function fetchGenres () {
      try {
        const list = await getGenres()
        setGenres(list)
      } catch (err) {
        // silently ignore genre errors
      }
    }
    fetchGenres()
  }, [])

  // Fetch movies whenever filters change
  useEffect(() => {
    async function fetchMovies () {
      try {
        setLoading(true)
        setError(null)
        let data
        if (query.trim() !== '') {
          data = await searchMovies(query, { page, year })
        } else {
          const options = {
            page,
            sort_by: sort,
            with_genres: selectedGenre || undefined,
            year: year || undefined,
            vote_average_gte: rating || undefined
          }
          data = await discoverMovies(options)
        }
        setMovies(data.results)
        setTotalPages(Math.min(data.total_pages, 500))
      } catch (err) {
        setError(err.message)
      } finally {
        setLoading(false)
      }
    }
    fetchMovies()
  }, [query, selectedGenre, year, rating, sort, page])

  // Reset page when filters other than page change
  useEffect(() => {
    setPage(1)
  }, [query, selectedGenre, year, rating, sort])

  const handleResetFilters = () => {
    setQuery('')
    setSelectedGenre('')
    setYear('')
    setRating(0)
    setSort('popularity.desc')
  }

  return (
    <Container sx={{ py: 4 }}>
      <Typography variant="h4" gutterBottom sx={{ fontWeight: 600 }}>
        Browse Movies
      </Typography>
      {/* Filter panel */}
      <Box
        sx={{
          mb: 4,
          p: 2,
          backgroundColor: 'background.paper',
          borderRadius: 2,
          boxShadow: 2
        }}
      >
        <Stack spacing={2} direction={{ xs: 'column', md: 'row' }}>
          <TextField
            label="Search"
            value={query}
            onChange={e => setQuery(e.target.value)}
            variant="outlined"
            fullWidth
            size="small"
          />
          <FormControl sx={{ minWidth: 150 }} size="small">
            <InputLabel id="genre-label">Genre</InputLabel>
            <Select
              labelId="genre-label"
              value={selectedGenre}
              label="Genre"
              onChange={e => setSelectedGenre(e.target.value)}
            >
              <MenuItem value="">
                <em>Any</em>
              </MenuItem>
              {genres.map(g => (
                <MenuItem key={g.id} value={g.id.toString()}>
                  {g.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
          <TextField
            label="Year"
            type="number"
            value={year}
            onChange={e => setYear(e.target.value)}
            inputProps={{ min: 1900, max: new Date().getFullYear(), step: 1 }}
            sx={{ width: 100 }}
            size="small"
          />
          <FormControl sx={{ minWidth: 180 }} size="small">
            <InputLabel id="sort-label">Sort By</InputLabel>
            <Select
              labelId="sort-label"
              value={sort}
              label="Sort By"
              onChange={e => setSort(e.target.value)}
            >
              <MenuItem value="popularity.desc">Popularity ↓</MenuItem>
              <MenuItem value="popularity.asc">Popularity ↑</MenuItem>
              <MenuItem value="release_date.desc">Release Date ↓</MenuItem>
              <MenuItem value="release_date.asc">Release Date ↑</MenuItem>
              <MenuItem value="vote_average.desc">Rating ↓</MenuItem>
              <MenuItem value="vote_average.asc">Rating ↑</MenuItem>
            </Select>
          </FormControl>
          <Box sx={{ display: 'flex', alignItems: 'center', width: 200 }}>
            <Typography variant="body2" sx={{ mr: 1 }}>
              Min Rating
            </Typography>
            <Slider
              value={rating}
              onChange={(e, val) => setRating(val)}
              valueLabelDisplay="auto"
              step={1}
              marks
              min={0}
              max={9}
            />
          </Box>
          <Button variant="outlined" onClick={handleResetFilters} size="small">
            Reset
          </Button>
        </Stack>
      </Box>
      {loading && (
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 6 }}>
          <CircularProgress />
        </Box>
      )}
      {error && (
        <Typography color="error" sx={{ my: 2 }}>
          {error}
        </Typography>
      )}
      {!loading && !error && movies.length === 0 && (
        <Typography sx={{ my: 2 }}>No movies found.</Typography>
      )}
      {!loading && movies.length > 0 && (
        <Grid container spacing={{ xs: 2, md: 3 }}>
          {movies.map(movie => (
            <Grid item xs={6} sm={4} md={3} lg={2} key={movie.id}>
              <MovieCard movie={movie} />
            </Grid>
          ))}
        </Grid>
      )}
      {!loading && totalPages > 1 && (
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <Pagination
            count={Math.min(totalPages, 20)}
            page={page}
            onChange={(e, value) => setPage(value)}
            color="primary"
          />
        </Box>
      )}
    </Container>
  )
}