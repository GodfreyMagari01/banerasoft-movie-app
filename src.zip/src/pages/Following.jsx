export default function Following () {
  return (
    <div style={{ padding: '2rem' }}>
      <h2>Following</h2>
      <p>This section will show videos from users you follow. Feature coming soon!</p>
    </div>
  )
}