import { useState, useEffect, useRef } from "react";
import {
  Box, Typography, Button, TextField, Dialog, DialogTitle, DialogContent,
  DialogActions, Card, CardContent, CardMedia, IconButton, Grid, Menu, MenuItem, InputAdornment
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import AddIcon from "@mui/icons-material/Add";
import EditIcon from "@mui/icons-material/Edit";
import DragHandleIcon from "@mui/icons-material/DragHandle";
import PhotoCamera from "@mui/icons-material/PhotoCamera";
import SearchIcon from "@mui/icons-material/Search";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";


// Helper functions to persist playlists in localStorage
const loadPlaylists = () => {
  try {
    return JSON.parse(localStorage.getItem("playlists-v2")) || [];
  } catch {
    return [];
  }
};
const savePlaylists = (data) => {
  localStorage.setItem("playlists-v2", JSON.stringify(data));
};

export default function Playlist() {
  const [playlists, setPlaylists] = useState([]);
  const [showDialog, setShowDialog] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newCover, setNewCover] = useState(""); // base64
  const [selected, setSelected] = useState(null);
  const [editIndex, setEditIndex] = useState(null);
  const [movieSearch, setMovieSearch] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [anchorEl, setAnchorEl] = useState(null);

  // Load on mount
  useEffect(() => { setPlaylists(loadPlaylists()); }, []);
  useEffect(() => { savePlaylists(playlists); }, [playlists]);

  // Drag & Drop reorder movies
  const handleDragEnd = result => {
    if (!result.destination) return;
    const reordered = Array.from(playlists[selected].movies);
    const [removed] = reordered.splice(result.source.index, 1);
    reordered.splice(result.destination.index, 0, removed);
    setPlaylists(pls => pls.map((pl, i) => i === selected ? { ...pl, movies: reordered } : pl));
  };

  // Add playlist
  const handleCreate = () => {
    setPlaylists([
      ...playlists,
      { title: newTitle, desc: newDesc, cover: newCover, movies: [], public: false }
    ]);
    setShowDialog(false); setNewTitle(""); setNewDesc(""); setNewCover("");
  };

  // Edit playlist
  const handleEdit = () => {
    setPlaylists(pls =>
      pls.map((pl, i) =>
        i === editIndex ? { ...pl, title: newTitle, desc: newDesc, cover: newCover } : pl
      )
    );
    setEditIndex(null); setShowDialog(false); setNewTitle(""); setNewDesc(""); setNewCover("");
  };

  // Add movie by TMDb search
  const handleMovieSearch = async q => {
    setMovieSearch(q);
    if (q.length < 2) return setSearchResults([]);
    const res = await fetch(
      `https://api.themoviedb.org/3/search/movie?api_key=${import.meta.env.VITE_TMDB_API_KEY}&query=${encodeURIComponent(q)}`
    );
    const data = await res.json();
    setSearchResults(data.results || []);
  };

  // Add movie to playlist
  const handleAddMovie = (movie) => {
    setPlaylists(pls => pls.map((pl, i) =>
      i === selected
        ? { ...pl, movies: pl.movies.find(m => m.id === movie.id) ? pl.movies : [...pl.movies, movie] }
        : pl
    ));
    setMovieSearch(""); setSearchResults([]);
  };

  // Remove movie
  const handleRemoveMovie = (movieId) => {
    setPlaylists(pls => pls.map((pl, i) =>
      i === selected ? { ...pl, movies: pl.movies.filter(m => m.id !== movieId) } : pl
    ));
  };

  // Change cover image
  const fileInput = useRef();
  const handleCoverUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => setNewCover(ev.target.result);
    reader.readAsDataURL(file);
  };

  // Toggle public/private
  const handleTogglePublic = (idx) => {
    setPlaylists(pls => pls.map((pl, i) =>
      i === idx ? { ...pl, public: !pl.public } : pl
    ));
  };

  // Edit playlist
  const openEdit = (idx) => {
    setEditIndex(idx);
    setNewTitle(playlists[idx].title);
    setNewDesc(playlists[idx].desc);
    setNewCover(playlists[idx].cover || "");
    setShowDialog(true);
  };

  // Render
  return (
    <Box sx={{ p: { xs: 1, md: 4 } }}>
      <Typography variant="h4" fontWeight={700} gutterBottom>Playlists</Typography>
      <Button
        variant="contained"
        color="primary"
        startIcon={<AddIcon />}
        onClick={() => { setShowDialog(true); setEditIndex(null); }}
        sx={{ mb: 3 }}
      >
        New Playlist
      </Button>
      <Grid container spacing={2}>
        {playlists.map((pl, idx) => (
          <Grid item xs={12} sm={6} md={4} key={idx}>
            <Card
              sx={{
                minHeight: 150,
                cursor: "pointer",
                bgcolor: selected === idx ? "grey.900" : "grey.800",
                display: "flex", alignItems: "center", px: 2, py: 2, position: "relative"
              }}
              onClick={() => setSelected(idx)}
            >
              <CardMedia
                component="img"
                image={pl.cover || (pl.movies[0]?.poster_path
                  ? `https://image.tmdb.org/t/p/w300${pl.movies[0].poster_path}` : "/no-poster.png")}
                alt={pl.title}
                sx={{ width: 60, height: 60, borderRadius: 2, objectFit: "cover", mr: 2 }}
              />
              <Box>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>{pl.title}</Typography>
                <Typography variant="body2" sx={{ mb: 1 }}>{pl.desc}</Typography>
                <Button
                  size="small"
                  variant="outlined"
                  onClick={e => { e.stopPropagation(); handleTogglePublic(idx); }}
                  sx={{ fontSize: 11, mt: 1 }}
                >
                  {pl.public ? "Public" : "Private"}
                </Button>
              </Box>
              <IconButton sx={{ position: "absolute", top: 8, right: 40 }} onClick={e => { e.stopPropagation(); openEdit(idx); }}>
                <EditIcon fontSize="small" />
              </IconButton>
              <IconButton sx={{ position: "absolute", top: 8, right: 8 }} onClick={e => { e.stopPropagation(); setPlaylists(pls => pls.filter((_, i) => i !== idx)); }}>
                <DeleteIcon fontSize="small" />
              </IconButton>
            </Card>
          </Grid>
        ))}
      </Grid>
      {/* Playlist detail */}
      {selected !== null && playlists[selected] && (
        <Box sx={{ mt: 3 }}>
          <Typography variant="h5" fontWeight={700} gutterBottom>
            {playlists[selected].title}
          </Typography>
          <Typography variant="body1" sx={{ mb: 2 }}>{playlists[selected].desc}</Typography>
          {/* Add by search */}
          <Box sx={{ display: "flex", alignItems: "center", mb: 2 }}>
            <TextField
              label="Add Movie by Title"
              size="small"
              value={movieSearch}
              onChange={e => handleMovieSearch(e.target.value)}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
              sx={{ width: { xs: "100%", md: 300 } }}
            />
          </Box>
          {searchResults.length > 0 && (
            <Box sx={{ maxHeight: 250, overflowY: "auto", mb: 2 }}>
              {searchResults.map((m) => (
                <Card key={m.id} sx={{ my: 1, cursor: "pointer", display: "flex", alignItems: "center" }} onClick={() => handleAddMovie(m)}>
                  <CardMedia
                    component="img"
                    image={m.poster_path ? `https://image.tmdb.org/t/p/w92${m.poster_path}` : "/no-poster.png"}
                    alt={m.title}
                    sx={{ width: 50, height: 70, objectFit: "cover", mr: 2 }}
                  />
                  <CardContent>
                    <Typography variant="subtitle2">{m.title}</Typography>
                    <Typography variant="caption">{m.release_date?.slice(0, 4)}</Typography>
                  </CardContent>
                </Card>
              ))}
            </Box>
          )}
          {/* Drag and drop movies */}
          <DragDropContext onDragEnd={handleDragEnd}>
            <Droppable droppableId="movies-droppable">
              {(provided) => (
                <Grid
                  container
                  spacing={2}
                  ref={provided.innerRef}
                  {...provided.droppableProps}
                >
                  {playlists[selected].movies.length === 0 && (
                    <Typography variant="body2" color="text.secondary" sx={{ ml: 2 }}>
                      No movies in this playlist yet.
                    </Typography>
                  )}
                  {playlists[selected].movies.map((movie, i) => (
                    <Draggable key={movie.id} draggableId={movie.id.toString()} index={i}>
                      {(prov) => (
                        <Grid
                          item xs={12} sm={6} md={4}
                          ref={prov.innerRef}
                          {...prov.draggableProps}
                          {...prov.dragHandleProps}
                        >
                          <Card>
                            <Box sx={{ display: "flex", alignItems: "center" }}>
                              <CardMedia
                                component="img"
                                image={movie.poster_path
                                  ? `https://image.tmdb.org/t/p/w300${movie.poster_path}` : "/no-poster.png"}
                                alt={movie.title}
                                sx={{ width: 70, height: 100, objectFit: "cover", mr: 1 }}
                              />
                              <CardContent sx={{ flex: 1 }}>
                                <Typography variant="subtitle1" noWrap>
                                  {movie.title}
                                </Typography>
                                <Typography variant="caption">
                                  {movie.release_date?.slice(0, 4)}
                                </Typography>
                              </CardContent>
                              <IconButton onClick={() => handleRemoveMovie(movie.id)}><DeleteIcon /></IconButton>
                              <DragHandleIcon color="disabled" />
                            </Box>
                          </Card>
                        </Grid>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </Grid>
              )}
            </Droppable>
          </DragDropContext>
        </Box>
      )}
      {/* Dialog for create/edit playlist */}
      <Dialog open={showDialog} onClose={() => setShowDialog(false)}>
        <DialogTitle>{editIndex !== null ? "Edit Playlist" : "New Playlist"}</DialogTitle>
        <DialogContent>
          <TextField
            label="Playlist Title"
            fullWidth margin="normal"
            value={newTitle}
            onChange={e => setNewTitle(e.target.value)}
          />
          <TextField
            label="Description"
            fullWidth margin="normal"
            value={newDesc}
            onChange={e => setNewDesc(e.target.value)}
          />
          {/* Cover image upload */}
          <Box sx={{ mt: 2 }}>
            <input
              accept="image/*"
              style={{ display: "none" }}
              id="playlist-cover-upload"
              type="file"
              ref={fileInput}
              onChange={handleCoverUpload}
            />
            <label htmlFor="playlist-cover-upload">
              <Button variant="outlined" color="primary" component="span" startIcon={<PhotoCamera />}>
                Upload Cover
              </Button>
            </label>
            {newCover && (
              <img src={newCover} alt="cover" style={{ marginLeft: 16, height: 60, borderRadius: 8 }} />
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowDialog(false)}>Cancel</Button>
          <Button
            onClick={editIndex !== null ? handleEdit : handleCreate}
            disabled={!newTitle.trim()}
            variant="contained"
          >
            {editIndex !== null ? "Save" : "Create"}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
