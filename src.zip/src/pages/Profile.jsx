import { useState, useMemo } from 'react'
import { Box, Typography, Card, CardContent, Grid, Avatar, Button, Select, MenuItem, FormControl, InputLabel, Stack } from '@mui/material'
import { Rating } from '@mui/material'
import { useUser } from '@clerk/clerk-react'
import { useWatchlist } from '../context/WatchlistContext'

/*
 * Profile page shows the authenticated user's account details and
 * personalised statistics. It summarises watchlist activity, lets
 * users categorise watchlist items (plan, watching, watched), rate
 * movies and displays counts per category. Users can also toggle
 * themes or update profile info here (future enhancement).
 */
export default function Profile () {
  const { user } = useUser()
  const { watchlist, updateWatchlistStatus, setWatchlistRating } = useWatchlist()

  // Compute counts by status and average rating
  const stats = useMemo(() => {
    const counts = { plan: 0, watching: 0, watched: 0 }
    let ratingSum = 0
    let ratingCount = 0
    watchlist.forEach(item => {
      counts[item.status] = (counts[item.status] || 0) + 1
      if (item.rating) {
        ratingSum += item.rating
        ratingCount += 1
      }
    })
    const averageRating = ratingCount > 0 ? (ratingSum / ratingCount).toFixed(1) : 'N/A'
    return { counts, averageRating }
  }, [watchlist])

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant='h4' sx={{ mb: 3, fontWeight: 700 }}>Profile</Typography>
      {user && (
        <Box sx={{ display: 'flex', alignItems: 'center', mb: 4 }}>
          <Avatar src={user.imageUrl} sx={{ width: 64, height: 64, mr: 2 }} />
          <Box>
            <Typography variant='h6'>{user.fullName || user.username}</Typography>
            <Typography variant='body2' sx={{ color: 'text.secondary' }}>{user.primaryEmailAddress?.emailAddress}</Typography>
          </Box>
        </Box>
      )}
      {/* Stats cards */}
      <Grid container spacing={2} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={4}>
          <Card sx={{ backgroundColor: 'background.paper' }}>
            <CardContent>
              <Typography variant='subtitle2' sx={{ color: 'text.secondary' }}>Plan to Watch</Typography>
              <Typography variant='h5'>{stats.counts.plan}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card sx={{ backgroundColor: 'background.paper' }}>
            <CardContent>
              <Typography variant='subtitle2' sx={{ color: 'text.secondary' }}>Watching</Typography>
              <Typography variant='h5'>{stats.counts.watching}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card sx={{ backgroundColor: 'background.paper' }}>
            <CardContent>
              <Typography variant='subtitle2' sx={{ color: 'text.secondary' }}>Watched</Typography>
              <Typography variant='h5'>{stats.counts.watched}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} sm={4}>
          <Card sx={{ backgroundColor: 'background.paper' }}>
            <CardContent>
              <Typography variant='subtitle2' sx={{ color: 'text.secondary' }}>Average Rating</Typography>
              <Typography variant='h5'>{stats.averageRating}</Typography>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
      {/* Watchlist details */}
      <Typography variant='h6' sx={{ mb: 2, fontWeight: 600 }}>Your Watchlist</Typography>
      {watchlist.length === 0 ? (
        <Typography variant='body2' sx={{ color: 'text.secondary' }}>Your watchlist is empty.</Typography>
      ) : (
        <Grid container spacing={2}>
          {watchlist.map(item => (
            <Grid item key={item.id} xs={12} md={6} lg={4}>
              <Card sx={{ display: 'flex', backgroundColor: 'background.paper' }}>
                <Box sx={{ width: 100, flexShrink: 0 }}>
                  <img
                    src={item.poster_path ? `https://image.tmdb.org/t/p/w185${item.poster_path}` : ''}
                    alt={item.title}
                    style={{ width: '100%', height: '100%', objectFit: 'cover', borderTopLeftRadius: 8, borderBottomLeftRadius: 8 }}
                  />
                </Box>
                <CardContent sx={{ flexGrow: 1 }}>
                  <Typography variant='subtitle1' sx={{ fontWeight: 600 }}>{item.title}</Typography>
                  <Typography variant='body2' sx={{ color: 'text.secondary' }}>{item.release_date}</Typography>
                  {/* Status selector */}
                  <FormControl fullWidth size='small' sx={{ mt: 1 }}>
                    <InputLabel>Status</InputLabel>
                    <Select
                      label='Status'
                      value={item.status}
                      onChange={e => updateWatchlistStatus(item.id, e.target.value)}
                    >
                      <MenuItem value='plan'>Plan to Watch</MenuItem>
                      <MenuItem value='watching'>Watching</MenuItem>
                      <MenuItem value='watched'>Watched</MenuItem>
                    </Select>
                  </FormControl>
                  {/* Rating */}
                  <Stack direction='row' alignItems='center' sx={{ mt: 1 }}>
                    <Typography variant='body2' sx={{ mr: 1 }}>Your Rating:</Typography>
                    <Rating
                      name={`rating-${item.id}`}
                      value={item.rating || 0}
                      precision={0.5}
                      max={10}
                      onChange={(_, newValue) => setWatchlistRating(item.id, newValue)}
                    />
                  </Stack>
                </CardContent>
              </Card>
            </Grid>
          ))}
        </Grid>
      )}
    </Box>
  )
}