import { useState } from 'react'
import { Box, List, ListItemButton, ListItemIcon, ListItemText, Avatar, Typography, Divider, IconButton, Tooltip } from '@mui/material'
import HomeIcon from '@mui/icons-material/Home'
import WhatshotIcon from '@mui/icons-material/Whatshot'
import PeopleAltIcon from '@mui/icons-material/PeopleAlt'
import VideoLibraryIcon from '@mui/icons-material/VideoLibrary'
import PlaylistPlayIcon from '@mui/icons-material/PlaylistPlay'
import ExpandMoreIcon from '@mui/icons-material/ExpandMore'
import ExpandLessIcon from '@mui/icons-material/ExpandLess'
import { Link as RouterLink, useLocation } from 'react-router-dom'

/*
 * SideNav renders a permanent sidebar on the left side of the application.
 * It displays the primary navigation items as well as a list of followed
 * users.  The active route is highlighted.  The design follows the
 * reference screenshot with rounded nav items and a dark background.
 */

const navItems = [
  { label: 'Browse', icon: <HomeIcon />, path: '/' },
  { label: 'Trending', icon: <WhatshotIcon />, path: '/movies' },
  { label: 'Following', icon: <PeopleAltIcon />, path: '/following' },
  { label: 'Your Videos', icon: <VideoLibraryIcon />, path: '/your-videos' },
  { label: 'Playlist', icon: <PlaylistPlayIcon />, path: '/playlist' },
  { label: 'Profile', icon: <PlaylistPlayIcon />, path: '/profile' }
]

// Sample list of followed users.  In a real application this would be
// fetched from your backend or user profile.  Each entry includes a
// username and a boolean indicating online status.
const sampleFollowing = [
  { name: 'Milan.G', avatar: 'https://i.pravatar.cc/150?u=milan', online: true },
  { name: 'Nick.B', avatar: 'https://i.pravatar.cc/150?u=nick', online: false },
  { name: 'Vika.J', avatar: 'https://i.pravatar.cc/150?u=vika', online: true },
  { name: 'Salome.B', avatar: 'https://i.pravatar.cc/150?u=salome', online: false },
  { name: 'Jessie.A', avatar: 'https://i.pravatar.cc/150?u=jessie', online: true },
  { name: 'Mura.H', avatar: 'https://i.pravatar.cc/150?u=mura', online: false }
]

export default function SideNav () {
  const location = useLocation()
  const [showAll, setShowAll] = useState(false)
  const displayedUsers = showAll ? sampleFollowing : sampleFollowing.slice(0, 5)

  return (
    <Box
      sx={{
        width: 240,
        flexShrink: 0,
        backgroundColor: '#0d0f11',
        color: 'rgba(255,255,255,0.87)',
        display: 'flex',
        flexDirection: 'column',
        height: '100vh',
        borderRight: '1px solid rgba(255,255,255,0.1)',
        position: 'sticky',
        top: 0
      }}
    >
      {/* Brand / Logo */}
      <Box sx={{ display: 'flex', alignItems: 'center', px: 2, py: 3 }}>
        <Avatar sx={{ mr: 1.5, bgcolor: 'primary.main' }}>B</Avatar>
        <Typography variant='h6' sx={{ fontWeight: 700 }}>
          BaneraSoft
        </Typography>
      </Box>
      {/* Navigation */}
      <List sx={{ flexGrow: 1 }}>
        {navItems.map(item => (
          <ListItemButton
            key={item.label}
            component={RouterLink}
            to={item.path}
            selected={location.pathname === item.path}
            sx={{
              my: 0.5,
              mx: 1,
              borderRadius: 2,
              '&.Mui-selected': {
                backgroundColor: 'primary.main',
                color: '#fff',
                '& .MuiListItemIcon-root': {
                  color: '#fff'
                }
              }
            }}
          >
            <ListItemIcon sx={{ color: 'inherit', minWidth: 40 }}>{item.icon}</ListItemIcon>
            <ListItemText primary={item.label} primaryTypographyProps={{ fontWeight: 500 }} />
          </ListItemButton>
        ))}
      </List>
      {/* Following section */}
      <Divider sx={{ borderColor: 'rgba(255,255,255,0.1)' }} />
      <Box sx={{ px: 2, py: 1 }}>
        <Typography variant='subtitle2' sx={{ color: 'rgba(255,255,255,0.6)', mb: 1 }}>
          Following
        </Typography>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {displayedUsers.map(u => (
            <Box key={u.name} sx={{ display: 'flex', alignItems: 'center' }}>
              <Avatar src={u.avatar} sx={{ width: 32, height: 32, mr: 1 }} />
              <Typography variant='body2' sx={{ flexGrow: 1 }}>
                {u.name}
              </Typography>
              {/* Online indicator */}
              <Box
                sx={{
                  width: 8,
                  height: 8,
                  borderRadius: '50%',
                  backgroundColor: u.online ? '#44b700' : 'rgba(255,255,255,0.3)'
                }}
              />
            </Box>
          ))}
        </Box>
        <Box sx={{ display: 'flex', justifyContent: 'flex-start', mt: 1 }}>
          <IconButton size='small' onClick={() => setShowAll(!showAll)} sx={{ color: 'primary.main' }}>
            {showAll ? <ExpandLessIcon fontSize='small' /> : <ExpandMoreIcon fontSize='small' />}
          </IconButton>
          <Typography variant='body2' sx={{ ml: 0.5, cursor: 'pointer' }} onClick={() => setShowAll(!showAll)}>
            {showAll ? 'Show less' : 'Load more'}
          </Typography>
        </Box>
      </Box>
    </Box>
  )
}