import { useState } from 'react'
import { Box, IconButton, InputBase, Paper, Button } from '@mui/material'
import SearchIcon from '@mui/icons-material/Search'
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone'
import { SignedIn, SignedOut, UserButton, SignInButton, SignUpButton } from '@clerk/clerk-react'

/*
 * TopBar sits at the top of the main content area.  It contains a search
 * field, notification bell and user authentication controls.  When the
 * user is not signed in, sign-in/up buttons are displayed.
 */

export default function TopBar () {
  const [searchValue, setSearchValue] = useState('')
  return (
    <Box
      sx={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        px: 3,
        py: 2,
        borderBottom: '1px solid rgba(255,255,255,0.1)'
      }}
    >
      {/* Search field */}
      <Paper
        component='form'
        sx={{
          display: 'flex',
          alignItems: 'center',
          width: { xs: '100%', sm: '50%' },
          backgroundColor: '#15171a',
          px: 1.5,
          py: 0.5,
          borderRadius: 2
        }}
        onSubmit={e => {
          e.preventDefault()
          // handle search action
        }}
      >
        <SearchIcon sx={{ mr: 1, color: 'rgba(255,255,255,0.6)' }} />
        <InputBase
          placeholder='Search everything'
          value={searchValue}
          onChange={e => setSearchValue(e.target.value)}
          sx={{ color: '#fff', flex: 1 }}
        />
      </Paper>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
        <IconButton sx={{ color: 'rgba(255,255,255,0.7)' }}>
          <NotificationsNoneIcon />
        </IconButton>
        <SignedIn>
          <UserButton afterSignOutUrl='/' appearance={{ elements: { avatarBox: { width: 36, height: 36 } } }} />
        </SignedIn>
        {/*
          Clerk's SignInButton and SignUpButton only accept a single child element
          or text node. Passing a MUI <Button> component with its own internal
          children causes runtime errors. To work around this, render simple
          span elements styled like buttons. These spans are the only
          children of the Clerk button components, satisfying the single child
          requirement while allowing us to control the appearance via the
          sx prop.
        */}
        <SignedOut>
          <SignInButton mode='modal'>
            <Box
              component='span'
              sx={{
                cursor: 'pointer',
                color: 'inherit',
                px: 2,
                py: 0.5,
                borderRadius: 1,
                fontSize: '0.875rem',
                '&:hover': { backgroundColor: 'rgba(255,255,255,0.08)' }
              }}
            >
              Sign&nbsp;In
            </Box>
          </SignInButton>
          <SignUpButton mode='modal'>
            <Box
              component='span'
              sx={{
                cursor: 'pointer',
                px: 2,
                py: 0.5,
                borderRadius: 1,
                border: '1px solid',
                borderColor: 'primary.main',
                color: 'primary.main',
                fontSize: '0.875rem',
                ml: 1,
                '&:hover': {
                  backgroundColor: 'rgba(255,255,255,0.1)',
                  borderColor: 'primary.light'
                }
              }}
            >
              Sign&nbsp;Up
            </Box>
          </SignUpButton>
        </SignedOut>
      </Box>
    </Box>
  )
}