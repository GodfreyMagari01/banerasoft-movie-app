import { createContext, useContext, useEffect, useState } from 'react'

/*
 * WatchlistContext holds state relating to the user's movie interaction
 * history. It tracks a list of movies added to the watchlist and a count
 * of how many movie cards have been viewed. This data is persisted to
 * localStorage so it survives page reloads and is scoped per browser.
 */

const WatchlistContext = createContext()

export function WatchlistProvider ({ children }) {
  const [watchlist, setWatchlist] = useState(() => {
    // initialise watchlist from localStorage
    try {
      const stored = window.localStorage.getItem('watchlist')
      return stored ? JSON.parse(stored) : []
    } catch (err) {
      return []
    }
  })
  const [browseCount, setBrowseCount] = useState(() => {
    try {
      const stored = window.localStorage.getItem('browseCount')
      return stored ? JSON.parse(stored) : 0
    } catch (err) {
      return 0
    }
  })

  // Persist watchlist changes
  useEffect(() => {
    window.localStorage.setItem('watchlist', JSON.stringify(watchlist))
  }, [watchlist])
  // Persist browse count
  useEffect(() => {
    window.localStorage.setItem('browseCount', JSON.stringify(browseCount))
  }, [browseCount])

  const addToWatchlist = movie => {
    setWatchlist(prev => {
      // avoid duplicates
      if (prev.find(item => item.id === movie.id)) return prev
      return [...prev, movie]
    })
  }

  const removeFromWatchlist = id => {
    setWatchlist(prev => prev.filter(item => item.id !== id))
  }

  const incrementBrowseCount = () => setBrowseCount(count => count + 1)

  return (
    <WatchlistContext.Provider
      value={{ watchlist, browseCount, addToWatchlist, removeFromWatchlist, incrementBrowseCount }}
    >
      {children}
    </WatchlistContext.Provider>
  )
}

export function useWatchlist () {
  const context = useContext(WatchlistContext)
  if (!context) throw new Error('useWatchlist must be used within a WatchlistProvider')
  return context

  const setWatchlistRating = (id, rating) => {
    setWatchlist(prev =>
      prev.map(item =>
        item.id === id ? { ...item, rating } : item
      )
    );
  };
}