import axios from 'axios'

/*
 * This service wraps all requests to the TMDb (The Movie Database) API.
 * Calls are centralised here so other modules can import functions without
 * repeating the base URL or API key logic. The API key is read from
 * Vite environment variables (VITE_TMDB_API_KEY). When running the
 * application locally, copy the `.env.example` file to `.env` and provide
 * your API key.
 */

const API_BASE_URL = 'https://api.themoviedb.org/3'
const API_KEY = import.meta.env.VITE_TMDB_API_KEY

// Pre-configured axios instance with base URL and default params
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  params: {
    api_key: API_KEY,
    language: 'en-US'
  }
})

// Fetch trending movies (daily). Accepts a page number for pagination.
export async function getTrendingMovies (page = 1) {
  const { data } = await apiClient.get('/trending/movie/day', { params: { page } })
  return data
}

// Fetch popular movies. Accepts a page number for pagination.
export async function getPopularMovies (page = 1) {
  const { data } = await apiClient.get('/movie/popular', { params: { page } })
  return data
}

// Search movies by query string. Additional options like year and page can
// be supplied via the options object. When no query is provided the API
// returns an empty result set.
export async function searchMovies (query, options = {}) {
  const { page = 1, year, includeAdult = false } = options
  const { data } = await apiClient.get('/search/movie', {
    params: {
      query,
      page,
      year,
      include_adult: includeAdult
    }
  })
  return data
}

// Discover movies using filters like year, genre, sort order etc.
// See TMDb docs for supported parameters. We expose a friendly options
// object; any unsupported keys are ignored by the API.
export async function discoverMovies (options = {}) {
  const {
    page = 1,
    with_genres,
    year,
    vote_average_gte,
    sort_by = 'popularity.desc'
  } = options
  const { data } = await apiClient.get('/discover/movie', {
    params: {
      page,
      with_genres,
      primary_release_year: year,
      'vote_average.gte': vote_average_gte,
      sort_by
    }
  })
  return data
}

// Fetch detailed information for a single movie by ID
export async function getMovieDetail (id) {
  const { data } = await apiClient.get(`/movie/${id}`)
  return data
}

// Fetch a list of movie genres. Returns an array of objects with `id`
// and `name` properties. Useful for populating filter dropdowns.
export async function getGenres () {
  const { data } = await apiClient.get('/genre/movie/list')
  return data.genres
}